new Vue ({
    el: "#app",
    data: {
        tamanho: 0

    },
    methods: {

    }
})